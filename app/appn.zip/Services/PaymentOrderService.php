<?php

namespace App\Services;

class PaymentOrderService
{
    public static function generatePaymentOrder($user, $amount, $currency, $paidAt = null, $orderId = null, $provider = null){

    }
}
