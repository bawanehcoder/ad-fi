<?php

namespace App\Filament\Resources\OptionDetilResource\Pages;

use App\Filament\Resources\OptionDetilResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateOptionDetil extends CreateRecord
{
    protected static string $resource = OptionDetilResource::class;
}
