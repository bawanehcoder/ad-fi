<?php

namespace App\Filament\Resources\OrderRejectedResource\Pages;

use App\Filament\Resources\OrderRejectedResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateOrderRejected extends CreateRecord
{
    protected static string $resource = OrderRejectedResource::class;
}
