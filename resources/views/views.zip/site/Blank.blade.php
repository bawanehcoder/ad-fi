@extends('site.layout.master')
@section('title') @langucw('') @endsection
@section('css') @endsection
@section('breadcrumb')
    <li><a href="{{route('home')}}">@langucw('home')</a></li>
    <li>@langucw('my account')</li>
@endsection
@section('content')

@endsection
@section('scripts') @endsection
