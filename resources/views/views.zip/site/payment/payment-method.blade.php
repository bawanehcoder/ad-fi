<div class="checkout-box">

    <div class="single-method form-check">
        <input class="form-check-input" type="checkbox" id="terms_conditions">
        <label class="form-check-label" for="terms_conditions">@langucw('لقد قرات ووافقت على شروط الموقع وسياسة الخصوصية')</label>
    </div>
    <button class="btn btn-dark btn-primary-hover rounded-0 mt-6" onclick="CompleteReques()">@langucw('اكمال الطلب')</button>

</div>
