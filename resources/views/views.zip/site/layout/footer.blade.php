<div class="footer">
    <div class="footer-container">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="info">
                        <img src="{{ asset('asset-files/imgs/logo-gold.png') }}" alt="Logo">
                        <p>
                            هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص
                            العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص
                        </p>
                        <div class="social-icons">
                            <a class="ms-3" href="#"><i class="fab fa-instagram"></i></a>
                            <a class="ms-3" href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a class="ms-3" href="#"><i class="fab fa-facebook"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-4">
                    <div class="contact">
                        <h3>للتواصل</h3>
                        <p>العنوان هنا العنوان هنا العنوان هنا العنوان هنا</p>
                        <p>البريد الإلكتروني: info@akhodoniya.com</p>
                        <p>الهاتف: +966 61451654152</p>
                    </div>
                </div>

            </div>
        </div>


    </div>
    <div class="footer-bottom">
        Copyright@jolife
    </div>
</div><!--end footer-->