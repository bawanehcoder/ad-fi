<div class="quickview-product-modal modal fade" id="modalCart">
    <div class="modal-dialog modal-dialog-centered mw-100">
        <div class="custom-content">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                <i class="lastudioicon lastudioicon-e-remove"></i>
            </button>
            <div class="modal-body">
                <i class="dlicon files_check"></i> Added To Cart Successfully!
            </div>
        </div>
    </div>
</div>
