{{-- share on social media --}}
<div class="product-share">
    <a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u={{ url()->current()  }}"><i class="lastudioicon-b-facebook"></i></a>
    <a target="_blank" href="https://twitter.com/share?url={{ url()->current()  }}"><i class="lastudioicon-b-twitter"></i></a>
</div>


