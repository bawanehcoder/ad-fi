<div class="offcanvas offcanvas-start offcanvas-cart" id="offcanvasCart">
    <div class="offcanvas-header">
        <h4 class="offcanvas-title">@langucw('my cart')</h4>
        <button type="button" class="btn-close text-secondary" data-bs-dismiss="offcanvas">
            X
        </button>
    </div>
    @include('components.cart.offcanvas-cart')
</div>

