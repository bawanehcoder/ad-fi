@extends('admin.layout.master')
@section('title') main-categories @endsection
@section('css') @endsection
@section('breadcrumb')
    <li class="breadcrumb-item"><a href="">{{trans('general.products_categories')}}</a></li>
    <li class="breadcrumb-item active">{{trans('general.categories')}}</li>
@endsection
@section('content')hhhhhhhhhhhhhhhhh @endsection
@section('scripts') @endsection
